# Dernier Gouvernement — Schemas & Exemples

Ce pack contient :
- `schemas/` : JSON Schema (draft 2020-12) pour KPI, CARDS, OBJECTIVES, DIFFICULTY
- `datasets/` : exemples valides pour démarrer (jeu de données démo).

## Ordre d'import recommandé
1. `datasets/KPI.json`
2. `datasets/CARDS.json`
3. `datasets/OBJECTIVES.json`
4. `datasets/DIFFICULTY.json`

## Notes
- Les KPI couvrent 13 ministères, 2 KPI par ministère, 6 mois d'historique.
- 21 cartes (budget, lois, décrets, diplomatie, communication, événements). 
- 9 objectifs (promesses de campagne) multi-difficulté.
- 3 modes de difficulté avec seuils Troïka.

Tous les fichiers sont UTF-8, dates `YYYY-MM`.
